########################################################################################################
# This script is used to test if CU5 update on SCOM 2007 R2 was successful on a Gateway Server        #
# Initial version by Bob Cornelissen March 2012
# Update by Bob Cornelissen 13-6-2012.
########################################################################################################
# Points to check, these come back as sections below:
# 0) Running prerequisite checks and gathering information
# 1) Check if CU5 installation log files contain an error
# 2) Check if updated files are located in the SCOM program files path
# 3) Check if agent update files are located in the SCOM agentmanagement directory
#
########################################################################################################
# Prerequisites:
# 1) You must be logged on with the same user account as the one who did the CU5 installation.
#    This is only for the Log Files check. It will jump to the next step if it can not find the logs.
########################################################################################################
Set-StrictMode -Version latest

########################################################################################################
# 0) Running prerequisite checks and gathering information
#
# Find the Management Group name
$rootKey = "HKLM:\Software\Microsoft\Microsoft Operations Manager\3.0\Server Management Groups"
$value   = "IsServer"
$i       = 0
Try
{
  Get-ChildItem $rootKey -Recurse -ErrorAction SilentlyContinue |
  ForEach-Object {
    If ((Get-ItemProperty -Path $_.PSPath) -Match $value)
    {
	$i++
	$mgRegpath = $_.PSChildName
    write-host "[Info] Management Group Name = $mgRegpath"
    }
  }
}
Catch
{
  write-host "Can not find management group name registry entry" -foregroundcolor Red
  exit 1
}
# If script finds multiple registry keys for managemnent groups it exits the script
If ($i -gt 1)
{
  Write-Host "[Error] You have multiple Management Group entries in the registry. Exiting script." -foregroundcolor Red
  exit 1
}

# If script does not find the registry key it will drop out, possibly not a gateway server.
If ($i -lt 1)
{
  Write-Host "[Error] Having trouble finding the management group name. Is this a gateway server? Exiting script." -foregroundcolor Red
  exit 1
}

# Check if this is run on a Gateway Server
#
function fnGetRegistryValue ($key, $value) {
(get-ItemProperty $key $value).$value
}

$MGRPRegKey = "HKLM:\Software\Microsoft\Microsoft Operations Manager\3.0\Server Management Groups\$mgRegpath"
$Command = fnGetRegistryValue $MGRPRegKey IsGateway
if ($Command -eq '1')
{ write-host "[Info] This is a Gateway, continue with script."}
else
{ 
write-host "[Error] This is not a Gateway. Please run the other script meant for Gateways or check if you entered the managemnent group name right - and this is case sensitive." -foregroundcolor Red
exit 1
}
#

# Get and check SCOM Install Path
$SCOMRegKey = "HKLM:\Software\Microsoft\Microsoft Operations Manager\3.0\Setup"
$SCOMInstallPath = fnGetRegistryValue $SCOMRegKey InstallDirectory
if ($SCOMInstallPath -eq $Null)
{ 
write-host "[Error] Can not find the registry key where SCOM is installed. Exit the script." -foregroundcolor Red
exit 1
}
else
{
write-host "[Info] SCOM is installed in the following path: $SCOMInstallPath"
}
#
########################################################################################################
# 1) Check if CU5 installation log files contain an error
#
Write-host "[Info] Finding CU5 install log files and checking them for errors."
Write-host "[Info] Looking for value 3 in the logs which would indicate a stopping error."
# Path to logs, this assumes logged in user is the same as who did the CU5 install.
# The logs are located in $FilePath = "C:\Users\<theuser>\AppData\Local\Temp" or a subdir.

function fnScanValue3 ($LogFileName)
{
# Check inside these logs for the string "value 3" without quotes
$MyOutput = select-string $LogFileName -pattern "Value 3"
# If this value 3 is not found than install was good, else it was not good
if($MyOutput -eq $Null)
	{
	write-host "[Success] This is good, no errors found in log $LogFileName." -Foregroundcolor Green
	}
else
	{
	write-host "[Error] Found errors. Open $LogFileName and check for the string: value 3" -foregroundcolor Red
	write-host "[Error] In the first line where value 3 is named and in approximately the 15 lines above that line it should state the problem." -foregroundcolor Red
	exit 1
	}
}

$FilePath = $env:localappdata
$status = $False
# Find log files from CU5 update
Get-Childitem -Recurse -Path $FilePath -include "KB2495674*.log" | Foreach-Object { 
write-host "[Info] Looking for value 3 in the log file: $_"
fnScanValue3 $_
$status = $True
}
If ($status -eq $False)
{
WRITE-host "[Error] Your temp dir $FilePath and subdirectories have no CU5 files. Check if you are logged on with the same user account as the one who ran CU5 update." -foregroundcolor Red
}

#
Write-host "[Info] Ready checking logs. Now checking for updated files."
########################################################################################################
# 2) Check if updates files are located in the SCOM program files path
#
# Function to check if files are a certain version and if they exist
# We need: file name, path to file, expected version
# example:
# fnCheckFileVersion "HealthService.dll" "C:\Program Files\System Center Operations Manager 2007" "6.1.7221.81"

Function fnCheckFileVersion ($FileName, $FilePath, $FileVersion)
{
if (Test-Path $FilePath\$FileName)
   { 
 Write-host "[Info]" $FileName "exists and is in the expected path."
 $HSDLLversion = (dir $FilePath\$FileName).VersionInfo |select FileVersion
if ($HSDLLversion.FileVersion -eq $FileVersion)
{ 
Write-host "[Success]" $FileName "has the right version:" $HSDLLversion.FileVersion -foregroundcolor Green
}
else
{ 
Write-host "[Error]" $FileName "has version:" $HSDLLversion.FileVersion "while expecting version:"$FileVersion -foregroundcolor Red
}

    }
  else
   {
  Write-host "[Error]" $FileName "The file does not exist in the expected path." -foregroundcolor Red
    }
}
#
Write-host "[Info] Check if a number of files exist and have the right version."
# Enter files and folders to check
# Because a number of files are in the same path and have to be the same version we define those first
$FilePath = $SCOMInstallPath
$FileVersion = "6.1.7221.81"
# This is the list of files to check

fnCheckFileVersion "EventCommon.dll" $FilePath $FileVersion
fnCheckFileVersion "HealthService.dll" $FilePath $FileVersion
fnCheckFileVersion "HealthServiceMessages.dll" $FilePath $FileVersion
fnCheckFileVersion "HealthServicePerformance.dll" $FilePath $FileVersion
fnCheckFileVersion "HealthServiceRuntime.dll" $FilePath $FileVersion
fnCheckFileVersion "HSLockdown.exe" $FilePath $FileVersion
fnCheckFileVersion "Microsoft.EnterpriseManagement.HealthService.Modules.WorkflowFoundation.dll" $FilePath $FileVersion
fnCheckFileVersion "Microsoft.EnterpriseManagement.Modules.Azure.dll" $FilePath $FileVersion
fnCheckFileVersion "Microsoft.Mom.Common.dll" $FilePath $FileVersion
fnCheckFileVersion "Microsoft.Mom.Modules.DataTypes.dll" $FilePath $FileVersion
fnCheckFileVersion "MOMConnector.dll" $FilePath $FileVersion
fnCheckFileVersion "MomConnectorMessages.dll" $FilePath $FileVersion
fnCheckFileVersion "MOMConnectorPerformance.dll" $FilePath $FileVersion
fnCheckFileVersion "MomIISModules.dll" $FilePath $FileVersion
fnCheckFileVersion "MOMModuleMsgs.dll" $FilePath $FileVersion
fnCheckFileVersion "MOMModules.dll" $FilePath $FileVersion
fnCheckFileVersion "MOMModules2.dll" $FilePath $FileVersion
fnCheckFileVersion "MOMNetworkModules.dll" $FilePath $FileVersion
fnCheckFileVersion "MOMPerfSnapshotHelper.exe" $FilePath $FileVersion
fnCheckFileVersion "MOMScriptAPI.dll" $FilePath $FileVersion
fnCheckFileVersion "MOMWsManModules.dll" $FilePath $FileVersion
fnCheckFileVersion "MonitoringHost.exe" $FilePath $FileVersion
fnCheckFileVersion "MOMAgentManagement.dll" $FilePath $FileVersion

#
Write-host "[Info] File check finished."
#
##################################################################################
# 3) Check if agent update files are located in the SCOM agentmanagement directory
#
Write-host "[Info] Check if agent update files are in agentmanagement folder"
#
# This function only checks if a file exists. Enter the full path to the file and the file name.
Function fnCheckFileExist ($FilePath, $FileName)
{
if (Test-Path $FilePath)
{
  if (Test-Path $FilePath\$FileName)
   { 
 # The file is there, continue.
 Write-host "[Success] The CU5 agent update file" $FileName "is in the folder." -foregroundcolor Green
    }
  else
   {
 # The CU update file is not there, update is not ready.
 Write-host "[Error] The CU5 agent update file" $FileName "is NOT in the folder." -foregroundcolor Red
    }
 }
 else
 {
 # Expected path does not exist so can not check file.
 Write-host "[Error] Folder doet not exist, check if SCOM is installed in default path." -foregroundcolor Red
 }
}

# These are the paths and files to check
$FilePath = $SCOMInstallPath+"AgentManagement\amd64"
fnCheckFileExist $FilePath "KB2495674-x64-Agent.msp"
fnCheckFileExist $FilePath "KB2495674-x64-ENU-Agent.msp"
$FilePath = $SCOMInstallPath+"AgentManagement\x86"
fnCheckFileExist $FilePath "KB2495674-x86-Agent.msp"
fnCheckFileExist $FilePath "KB2495674-x86-ENU-Agent.msp"
#
Write-host "[Info] Ready checking agent update files."
Write-host "[Info] Ready checking for successfull CU5 upgrade on the Gateway Server."
#
# End of script