########################################################################################################
# This script is used to test if CU6 update on SCOM 2007 R2 was successful on a Management Server      #
# This is for management servers other than the RMS server, which has a separate script                #
# Initial version by Bob Cornelissen June 2012
# Update by Bob Cornelissen 13-6-2012.
########################################################################################################
# Points to check, these come back as sections below:
# 0) Running prerequisite checks and gathering information
# 1) Check if CU6 installation log files contain an error
# 2) Check if updated files are located in the SCOM program files path
# 3) Check if agent update files are located in the SCOM agentmanagement directory
#
########################################################################################################
# Prerequisites:
# 1) You must be logged on with the same user account as the one who did the CU6 installation.
#    This is only for the Log Files check. It will jump to the next step if it can not find the logs.
########################################################################################################
Set-StrictMode -Version latest

########################################################################################################
# 0) Running prerequisite checks and gathering information
#
# Find the Management Group name
$rootKey = "HKLM:\Software\Microsoft\Microsoft Operations Manager\3.0\Server Management Groups"
$value   = "IsServer"
$i       = 0
Try
{
  Get-ChildItem $rootKey -Recurse -ErrorAction SilentlyContinue |
  ForEach-Object {
    If ((Get-ItemProperty -Path $_.PSPath) -Match $value)
    {
	$i++
	$mgRegpath = $_.PSChildName
    write-host "[Info] Management Group Name = $mgRegpath"
    }
  }
}
Catch
{
  write-host "Can not find management group name registry entry" -foregroundcolor Red
}
# If script finds multiple registry keys for managemnent groups it exits the script
If ($i -gt 1)
{
  Write-Host "[Error] You have multiple Management Group entries in the registry. Exiting script." -foregroundcolor Red
  exit 1
}

# Check if this is run on an MS but not the RMS
# First check if this server is the RMS for its management group, do not want to run this script on RMS.
function fnGetRegistryValue ($key, $value) {
(get-ItemProperty $key $value).$value
}
#
$RegKey = "HKLM:\Software\Microsoft\Microsoft Operations Manager\3.0\Server Management Groups\$mgRegpath"
$Command = fnGetRegistryValue $RegKey IsRootHealthService
if ($Command -eq '0')
{ write-host "[Info] This is not the RMS, continue with script."}
else
{ 
write-host "[Error] This is the RMS. Please run the other script meant for RMS." -foregroundcolor Red
exit 1
}

# Next check if this server is a Management Server and continue if it is.
$RegKey = "HKLM:\Software\Microsoft\Microsoft Operations Manager\3.0\Server Management Groups\$mgRegpath"
$Command = fnGetRegistryValue $RegKey IsServer
if ($Command -eq '1')
{ write-host "[Info] This is a Management Server, continue with script."}
else
{ 
write-host "[Error] This is not a Management Server. Please only run this script on a Management Server." -foregroundcolor Red
exit 1
}

# Get and check SCOM Install Path
$SCOMRegKey = "HKLM:\Software\Microsoft\Microsoft Operations Manager\3.0\Setup"
$SCOMInstallPath = fnGetRegistryValue $SCOMRegKey InstallDirectory
if ($SCOMInstallPath -eq $Null)
{ 
write-host "[Error] Can not find the registry key where SCOM is installed. Exit the script." -foregroundcolor Red
exit 1
}
else
{
write-host "[Info] SCOM is installed in the following path: $SCOMInstallPath"
}
#
########################################################################################################
# 1) Check if CU6 installation log files contain an error
#
Write-host "[Info] Finding CU6 install log files and checking them for errors."
Write-host "[Info] Looking for value 3 in the logs which would indicate a stopping error."
# Path to logs, this assumes logged in user is the same as who did the CU6 install.
# The logs are located in $FilePath = "C:\Users\<theuser>\AppData\Local\Temp" or a subdir.

function fnScanValue3 ($LogFileName)
{
# Check inside these logs for the string "value 3" without quotes
$MyOutput = select-string $LogFileName -pattern "Value 3"
# If this value 3 is not found than install was good, else it was not good
if($MyOutput -eq $Null)
	{
	write-host "[Success] This is good, no errors found in log $LogFileName." -Foregroundcolor Green
	}
else
	{
	write-host "[Error] Found errors. Open $LogFileName and check for the string: value 3" -foregroundcolor Red
	write-host "[Error] In the first line where value 3 is named and in approximately the 15 lines above that line it should state the problem." -foregroundcolor Red
	exit 1
	}
}

$FilePath = $env:localappdata
$status = $False
# Find log files from CU6 update
Get-Childitem -Recurse -Path $FilePath -include "KB2626076*.log" | Foreach-Object { 
write-host "[Info] Looking for value 3 in the log file: $_"
fnScanValue3 $_
$status = $True
}
If ($status -eq $False)
{
WRITE-host "[Error] Your temp dir $FilePath and subdirectories have no CU6 files. Check if you are logged on with the same user account as the one who ran CU6 update." -foregroundcolor Red
}

#
Write-host "[Info] Ready checking logs. Now checking for updated files."
########################################################################################################
# 2) Check if updates files are located in the SCOM program files path
#
# Function to check if files are a certain version and if they exist
# We need: file name, path to file, expected version
# fnCheckFileVersion "HealthService.dll" "C:\Program Files\System Center Operations Manager 2007" "6.1.7221.99"

Function fnCheckFileVersion ($FileName, $FilePath, $FileVersion)
{
if (Test-Path $FilePath\$FileName)
   { 
 Write-host "[Info]" $FileName "exists and is in the expected path."
 $HSDLLversion = (dir $FilePath\$FileName).VersionInfo |select FileVersion
if ($HSDLLversion.FileVersion -eq $FileVersion)
{ 
Write-host "[Success]" $FileName "has the right version:" $HSDLLversion.FileVersion -foregroundcolor Green
}
else
{ 
Write-host "[Error]" $FileName "has version:" $HSDLLversion.FileVersion "while expecting version:"$FileVersion -foregroundcolor Red
}

    }
  else
   {
  Write-host "[Error]" $FileName "The file does not exist in the expected path." -foregroundcolor Red
    }
}
#
Write-host "[Info] Check if a number of files exist and have the right version."
# Enter files and folders to check
# Because a number of files are in the same path and have to be the same version we define those first
$FilePath = $SCOMInstallPath
$FileVersion = "6.1.7221.99"
# This is the list of files to check


fnCheckFileVersion "AuditingMessages.dll" $FilePath $FileVersion
fnCheckFileVersion "EventCommon.dll" $FilePath $FileVersion
fnCheckFileVersion "HealthService.dll" $FilePath $FileVersion
fnCheckFileVersion "HealthServiceMessages.dll" $FilePath $FileVersion
fnCheckFileVersion "HealthServicePerformance.dll" $FilePath $FileVersion
fnCheckFileVersion "HealthServiceRuntime.dll" $FilePath $FileVersion
fnCheckFileVersion "HSLockdown.exe" $FilePath $FileVersion
fnCheckFileVersion "Microsoft.EnterpriseManagement.DataWarehouse.DataAccess.dll" $FilePath $FileVersion
fnCheckFileVersion "Microsoft.EnterpriseManagement.HealthService.Modules.DataWarehouse.dll" $FilePath $FileVersion
fnCheckFileVersion "Microsoft.EnterpriseManagement.HealthService.Modules.Notification.dll" $FilePath $FileVersion
fnCheckFileVersion "Microsoft.EnterpriseManagement.HealthService.Modules.WorkflowFoundation.dll" $FilePath $FileVersion
fnCheckFileVersion "Microsoft.EnterpriseManagement.Modules.Azure.dll" $FilePath $FileVersion
fnCheckFileVersion "Microsoft.EnterpriseManagement.OperationsManager.ClientShell.dll" $FilePath $FileVersion
fnCheckFileVersion "Microsoft.EnterpriseManagement.UI.Administration.dll" $FilePath $FileVersion
fnCheckFileVersion "Microsoft.EnterpriseManagement.UI.Authoring.dll" $FilePath $FileVersion
fnCheckFileVersion "Microsoft.EnterpriseManagement.UI.Reporting.dll" $FilePath $FileVersion
fnCheckFileVersion "Microsoft.Mom.Common.dll" $FilePath $FileVersion
fnCheckFileVersion "Microsoft.Mom.ConfigServiceHost.exe" $FilePath $FileVersion
fnCheckFileVersion "Microsoft.Mom.DataAccessLayer.dll" $FilePath $FileVersion
fnCheckFileVersion "Microsoft.Mom.DiscoveryDatabaseAccess.dll" $FilePath $FileVersion
fnCheckFileVersion "Microsoft.Mom.Modules.ClientMonitoring.dll" $FilePath $FileVersion
fnCheckFileVersion "Microsoft.Mom.Modules.DataTypes.dll" $FilePath $FileVersion
fnCheckFileVersion "Microsoft.Mom.Sdk.ServiceDataLayer.dll" $FilePath $FileVersion
fnCheckFileVersion "Microsoft.Mom.Sdk.ServiceHost.exe" $FilePath $FileVersion
fnCheckFileVersion "Microsoft.Mom.ServiceCommon.dll" $FilePath $FileVersion
fnCheckFileVersion "Microsoft.MOM.UI.Common.dll" $FilePath $FileVersion
fnCheckFileVersion "Microsoft.MOM.UI.Components.dll" $FilePath $FileVersion
fnCheckFileVersion "Microsoft.MOM.UI.Console.exe" $FilePath $FileVersion
fnCheckFileVersion "Microsoft.Mom.UI.Wrappers.dll" $FilePath $FileVersion
fnCheckFileVersion "MoMADAdmin.exe" $FilePath $FileVersion
fnCheckFileVersion "MOMAgentManagement.dll" $FilePath $FileVersion
fnCheckFileVersion "MOMConnector.dll" $FilePath $FileVersion
fnCheckFileVersion "MomConnectorMessages.dll" $FilePath $FileVersion
fnCheckFileVersion "MOMConnectorPerformance.dll" $FilePath $FileVersion
fnCheckFileVersion "MomIISModules.dll" $FilePath $FileVersion
fnCheckFileVersion "MOMModuleMsgs.dll" $FilePath $FileVersion
fnCheckFileVersion "MOMModules.dll" $FilePath $FileVersion
fnCheckFileVersion "MOMModules2.dll" $FilePath $FileVersion
fnCheckFileVersion "MOMMsgs.dll" $FilePath $FileVersion
fnCheckFileVersion "MOMNetworkModules.dll" $FilePath $FileVersion
fnCheckFileVersion "MOMPerfSnapshotHelper.exe" $FilePath $FileVersion
fnCheckFileVersion "MOMScriptAPI.dll" $FilePath $FileVersion
fnCheckFileVersion "MOMWsManModules.dll" $FilePath $FileVersion
fnCheckFileVersion "MonitoringHost.exe" $FilePath $FileVersion
fnCheckFileVersion "MPConvert.exe" $FilePath $FileVersion
fnCheckFileVersion "MPExport.exe" $FilePath $FileVersion
fnCheckFileVersion "MPImport.exe" $FilePath $FileVersion
fnCheckFileVersion "MPVerify.exe" $FilePath $FileVersion
fnCheckFileVersion "OpsMgrVssWriterService.exe" $FilePath $FileVersion
fnCheckFileVersion "SecureStorageBackup.exe" $FilePath $FileVersion
fnCheckFileVersion "SecureStorageSDK.dll" $FilePath $FileVersion

#
Write-host "[Info] File check finished."
#
##################################################################################
# 3) Check if agent update files are located in the SCOM agentmanagement directory
#
Write-host "[Info] Check if agent update files are in agentmanagement folder"
#
# This function only checks if a file exists. Enter the full path to the file and the file name.
Function fnCheckFileExist ($FilePath, $FileName)
{
if (Test-Path $FilePath)
{
  if (Test-Path $FilePath\$FileName)
   { 
 # The file is there, continue.
 Write-host "[Success] The CU6 agent update file" $FileName "is in the folder." -foregroundcolor Green
    }
  else
   {
 # The CU update file is not there, update is not ready.
 Write-host "[Error] The CU6 agent update file" $FileName "is NOT in the folder." -foregroundcolor Red
    }
 }
 else
 {
 # Expected path does not exist so can not check file.
 Write-host "[Error] Folder doet not exist, check if SCOM is installed in default path." -foregroundcolor Red
 }
}

# These are the paths and files to check
$FilePath = $SCOMInstallPath+"AgentManagement\amd64"
fnCheckFileExist $FilePath "KB2626076-x64-Agent.msp"
fnCheckFileExist $FilePath "KB2626076-x64-ENU-Agent.msp"
$FilePath = $SCOMInstallPath+"AgentManagement\x86"
fnCheckFileExist $FilePath "KB2626076-x86-Agent.msp"
fnCheckFileExist $FilePath "KB2626076-x86-ENU-Agent.msp"
#
Write-host "[Info] Ready checking agent update files."
Write-host "[Info] Ready checking for successfull CU6 upgrade on the Management Server."
#
# End of script